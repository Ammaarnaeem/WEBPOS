<?php

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pointofsales";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Handle add product form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add"])) {
  // Get data from form
  $name = $_POST["name"];
  $price = $_POST["price"];

  // Insert new product into database
  $sql = "INSERT INTO products (name, price) VALUES ('$name', '$price')";
  $conn->query($sql);
}

// Handle delete product form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete"])) {
  // Get ID of product to delete
  $id = $_POST["id"];

  // Delete product from database
  $sql = "DELETE FROM products WHERE product_id=$id";
  $conn->query($sql);
}

// Query database for all products
$sql = "SELECT * FROM products";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
  <title>Products</title>
  <?php include('template.php'); ?>
  <link rel="stylesheet" type="text/css" href="products.css">
</head>
<body>

  <h1>Products</h1>

  <!-- Add product form -->
  <div clas= "Add-placeholders">
        <form method="POST">
            <input type="text" name="name" placeholder="Name" required>
            <input type="number" name="price" placeholder="Price" min="1" required>
            <input type="submit" name="add" value="Add">
        </form>
  </div>

  <br>

  <!-- Products grid view -->
  <?php if ($result->num_rows > 0): ?>
    <table>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Price</th>
        <th>Action</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?php echo $row["product_id"]; ?></td>
          <td><?php echo $row["name"]; ?></td>
          <td><?php echo $row["price"]; ?></td>
          <td>
            <!-- Delete product form -->
            <form method="POST">
              <input type="hidden" name="id" value="<?php echo $row["product_id"]; ?>">
              <input type="submit" name="delete" value="Delete">
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  <?php else: ?>
    <p>No products found.</p>
  <?php endif; ?>

</body>
</html>

<?php
// Close database connection
$conn->close();
?>
