<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Template</title>
	<link rel="stylesheet" href="template.css">
</head>
<body>
	<header>
    <div class="panel">

		<h2>Point of Sales</h2>
		<ul>
			<li><a href="home.php"><img src="blackgoose_1.png" alt="Logo" class="logo"></a></li>
			<li><a href="products.php">Products</a></li>
			<li><a href="suppliers.php">Suppliers</a></li>
			<li><a href="cart.php">Cart</a></li>
			<li><a href="addEmployee.php">Add Employee</a></li>
		</ul>
	</div>
	</header>

</body>
</html>
