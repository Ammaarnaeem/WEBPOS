<!DOCTYPE html>
<html>
<head>
	<title>Suppliers Page</title>
    <?php include('template.php'); ?>
	<link rel="stylesheet" type="text/css" href="suppliers.css">
</head>
<body>
	<div class="main-content">
		<h1>Suppliers</h1>
		<form method="post">
			<label for="name">Supplier Name:</label>
			<input type="text" id="name" name="name" required>
			<label for="address">Address:</label>
			<input type="text" id="address" name="address" required>
			<label for="phone">Phone:</label>
			<input type="text" id="phone" name="phone" required>
			<input type="submit" name="add_supplier" value="Add Supplier">
		</form>
		<table>
			<thead>
				<tr>
					<th>ID</th>
					<th>Name</th>
					<th>Address</th>
					<th>Phone</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php
				// Connect to the database
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "pointofsales";

                    $conn = new mysqli($servername, $username, $password, $dbname);
                			// check if the connection was successful
			if (!$conn) {
				die("Connection failed: " . mysqli_connect_error());
			}

			// check if the add supplier form was submitted
			if (isset($_POST['add_supplier'])) {
				$name = $_POST['name'];
				$address = $_POST['address'];
				$phone = $_POST['phone'];
				$sql = "INSERT INTO suppliers (supplier_name, address, phone_number) VALUES ('$name', '$address', '$phone')";
				if (mysqli_query($conn, $sql)) {
					echo "<p>Supplier added successfully!</p>";
					header('Location: suppliers.php');
					exit;
				} else {
					echo "<p>Error: " . mysqli_error($conn) . "</p>";
				}
			}

			// check if the remove supplier form was submitted
			if (isset($_POST['remove_supplier'])) {
				$id = $_POST['supplier_id'];
				$sql = "DELETE FROM suppliers WHERE supplier_id=$id";
				if (mysqli_query($conn, $sql)) {
					echo "<p>Supplier removed successfully!</p>";
					header('Location: suppliers.php');
					exit;
				} else {
					echo "<p>Error: " . mysqli_error($conn) . "</p>";
				}
			}

            // check if the search supplier form was submitted
			if (isset($_POST['search_supplier'])) {
				$id = $_POST['supplier_id'];
				$sql = "SELECT * FROM suppliers WHERE supplier_id=$id";
				$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					echo "<tr><td>" . $row['supplier_id'] . "</td><td>" . $row['supplier_name'] . "</td><td>" . $row['address'] . "</td><td>" . $row['phone_number'] . "</td>";
					echo "<td><form method='post'><input type='hidden' name='id' value='" . $row['supplier_id'] . "'><input type='submit' name='remove_supplier' value='Remove'></form></td></tr>";
				}
			} else {
                echo "<p>No suppliers found.</p>";
            }
            
			}

			// display all suppliers
			$sql = "SELECT * FROM suppliers";
			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
				echo "<h2>All Suppliers</h2>";
				while ($row = mysqli_fetch_assoc($result)) {
					echo "<tr><td>" . $row['supplier_id'] . "</td><td>" . $row['supplier_name'] . "</td><td>" . $row['address'] . "</td><td>" . $row['phone_number'] . "</td>";
					echo "<td><form method='post'><input type='hidden' name='id' value='" . $row['supplier_id'] . "'><input type='submit' name='remove_supplier' value='Remove'></form></td></tr>";
				}
			} else {
                echo "<p>No suppliers found.</p>";
            }
            ?>
            </tbody>
            <!-- -------------------------------------------------------------------------   -->
            <?php
            // connect to the database
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "pointofsales";
            $conn = new mysqli($servername, $username, $password, $dbname);

            // check if the search supplier form was submitted
            if (isset($_POST['search_supplier'])) {
                $supplier_id = $_POST['supplier_id'];

                // prepare statement with placeholders
                $stmt = $conn->prepare("SELECT * FROM suppliers WHERE supplier_id = ?");
                // bind actual value to placeholder
                $stmt->bind_param("s", $supplier_id);
                // execute statement
                $stmt->execute();

                // get result set
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr><td>" . $row['supplier_id'] . "</td><td>" . $row['supplier_name'] . "</td><td>" . $row['address'] . "</td><td>" . $row['phone_number'] . "</td>";
                        echo "<td><form method='post'><input type='hidden' name='id' value='" . $row['supplier_id'] . "'><input type='submit' name='remove_supplier' value='Remove'></form></td></tr>";
                    }
                } else {
                    echo "0 results";
                }

                // close statement and result set
                $stmt->close();
                $result->close();
            }

            ?>
<!-- -------------------------------------------------------------------------   -->

                    </table>
                    <form method="post">
                        <h2>Search for a Supplier</h2>
                        <label for="supplier_id">Supplier ID:</label>
                        <input type="text" id="supplier_id" name="supplier_id" required>
                        <input type="submit" name="search_supplier" value="Search">
                    </form>

                    <br>

                    <br>
                    <form method="post">
                        <h2>Remove a Supplier</h2>
                        <label for="supplier_id">Supplier ID:</label>
                        <input type="text" id="supplier_id" name="supplier_id" required>
                        <input type="submit" name="remove_supplier" value="Remove Supplier">
                    </form>
                </div>
</body>
</html>            