<?php
// include('template.php');
session_start();

// Add item to cart
if(isset($_POST['cart'])){
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Check if cart already exists
    if(!isset($_SESSION['cart'])){
        $_SESSION['cart'] = array();
    }

    // Add item to cart
    $_SESSION['cart'][$product_id] = $quantity;

    // Redirect to cart page
    header('Location: cart.php');
    exit;
}

// Update item quantity in cart
if(isset($_POST['update_cart'])){
    $quantities = $_POST['quantity'];

    foreach($quantities as $product_id => $quantity){
        if($quantity == 0){
            // Remove item from cart if quantity is zero
            unset($_SESSION['cart'][$product_id]);
        }else{
            // Update item quantity in cart
            $_SESSION['cart'][$product_id] = $quantity;
        }
    }

    // Redirect to cart page
    header('Location: cart.php');
    exit;
}

// Remove item from cart
if(isset($_POST['remove_from_cart'])){
    $product_id = $_POST['product_id'];

    // Remove item from cart
    unset($_SESSION['cart'][$product_id]);

    // Redirect to cart page
    header('Location: cart.php');
    exit;
}

// Display cart items and total
$total = 0;
if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0){
    foreach($_SESSION['cart'] as $product_id => $quantity){
        // Fetch product details from database
        $pdo = new PDO('mysql:host=localhost;dbname=pointofsales', 'root', '');
        $stmt = $pdo->prepare('SELECT * FROM products WHERE product_id = :product_id');
        $stmt->bindParam(':product_id', $product_id);
        $stmt->execute();
        $product = $stmt->fetch();

        // Calculate total price for item
       // $price = $product['price'] * $quantity;
        //$total += $price;

        // Display item in cart
        echo '<div>';
        //echo '<h4>'.$product['name'].'</h4>';
        //echo '<p>Price: $'.$product['price'].'</p>';
        echo '<p>Quantity: '.$quantity.'</p>';
        // echo '<p>Total: $'.$price.'</p>';
        echo '<form method="post">';
        echo '<input type="hidden" name="product_id" value="'.$product_id.'">';
        echo '<input type="submit" name="remove_from_cart" value="Remove">';
        echo '</form>';
        echo '</div>';
    }

    // Display total price
    echo '<h4>Total: $'.$total.'</h4>';

    // Display form to update quantities
    echo '<form method="post">';
    foreach($_SESSION['cart'] as $product_id => $quantity){
        echo '<input type="hidden" name="quantity['.$product_id.']" value="'.$quantity.'">';
    }
    echo '<input type="submit" name="update_cart" value="Update Quantities">';
    echo '</form>';

}else{
    echo '<p>Your cart is empty.</p>';
}
?>
