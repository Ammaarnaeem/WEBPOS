<!DOCTYPE html>
<html>
  <head>
    <title>Add Employee</title>
    <?php include('template.php'); ?>
	<link rel="stylesheet" type="text/css" href="addEmployee.css">
  </head>
  <body>
    <h1>Add Employee</h1>
    <form action="addEmployee.php" method="post">
      <label for="name">Name:</label>
      <input type="text" name="name" required>
      <br>
      <label for="password">Password:</label>
      <input type="password" name="password" required>
      <br>
      <label for="email">Email:</label>
      <input type="email" name="email" required>
      <br>
      <label for="phone">Phone Number:</label>
      <input type="tel" name="phone" required>
      <br>
      <label for="address">Address:</label>
      <input type="text" name="address" required>
      <br>
      <input type="submit" value="Submit">
    </form>
    <?php

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pointofsales";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Prepare and bind the statement
  $stmt = $conn->prepare("INSERT INTO employee (name, password, email, phone, address) VALUES (?, ?, ?, ?, ?)");
  $stmt->bind_param("sssss", $name, $password, $email, $phone, $address);

  // Get form data
  $name = $_POST['name'];
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encrypt password
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $address = $_POST['address'];

  // Execute the statement
  if ($stmt->execute()) {
    echo "Sign up successful!";
    header("Location: addEmployee.php");
  } else {
    echo "Error: " . $stmt->error;
  }

  // Close the statement and database connection
  $stmt->close();
}

$conn->close();

?>


  </body>
</html>
<!--################################################### -->
