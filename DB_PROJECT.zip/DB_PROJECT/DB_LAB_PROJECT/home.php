<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<?php include('template.php'); ?>
	<link rel="stylesheet" type="text/css" href="home.css">
</head>
<body>
	
		<main>
		<?php
// start the session
session_start();

// initialize the shopping cart if it does not exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// define the items available for purchase
$items = array(
    array('id' => 'item1', 'name' => 'Item 1', 'price' => 10),
    array('id' => 'item2', 'name' => 'Item 2', 'price' => 20),
    array('id' => 'item3', 'name' => 'Item 3', 'price' => 30),
);

// check if the add to cart form was submitted
if (isset($_POST['cart'])) {
    // get the item ID and quantity from the form
    $item_id = $_POST['item_id'];
    $quantity = $_POST['quantity'];
    
    // check if the item ID is valid
    if (array_key_exists($item_id, $items)) {
        // add the item and quantity to the shopping cart
        if (array_key_exists($item_id, $_SESSION['cart'])) {
            $_SESSION['cart'][$item_id] += $quantity;
        } else {
            $_SESSION['cart'][$item_id] = $quantity;
        }
        
        // redirect to the shopping cart page
        header('Location: cart.php');
        exit;
    }
}

// display the home page
?>
<!DOCTYPE html>
<html>
<head>
    <title>Home Page</title>
</head>
<body>
    <h1>Home Page</h1>
    <br>
    <a href="addEmployee.php"><input type="submit" name="cart" value="Add Employee"></a>
    <h2>Available Items:</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
            <tr>
                <td><?php echo $item['id']; ?></td>
                <td><?php echo $item['name']; ?></td>
                <td>$<?php echo number_format($item['price'], 2); ?></td>
                <td>
                    <form method="post" action="cart.php">
                        <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                        <input type="number" name="quantity" value="1" min="1">
                </td>
                <td>
                        <input type="submit" name="cart" value="Add to Cart">
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>

		</main>
</body>
</html>
