<?php
session_start();
if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn']) {
    header('Location: home.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Login Page</title>
    <?php include('template.php'); ?>
	<link rel="stylesheet" type="text/css" href="loginPage.css">
  </head>
  <body>
    <h1>Login Page</h1>
    <form action="loginPage.php" method="post">
      <label for="name">Name:</label>
      <input type="text" name="name" required>
      <br>
      <label for="password">Password:</label>
      <input type="password" name="password" required>
      <br>
      <input type="submit" value="Login">
    </form>
    <?php
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Establish database connection
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "pointofsales";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and bind the statement
        $stmt = $conn->prepare("SELECT password FROM employee WHERE name = ?");
        $stmt->bind_param("s", $name);

        // Get form data
        $name = $_POST['name'];

        // Execute the statement
        $stmt->execute();

        // Bind the result variable
        $stmt->bind_result($hashedPassword);

        // Fetch the result
        $stmt->fetch();

        // Verify password
        if (password_verify($_POST['password'], $hashedPassword)) {
            // Password is correct, set session variable
            $_SESSION['loggedIn'] = true;
            header('Location: home.php');
            exit();
        } else {
            // Password is incorrect, display error message
            echo "Incorrect username or password.";
        }

        // Close the statement and database connection
        $stmt->close();
        $conn->close();
    }
?>
  </body>
</html>
