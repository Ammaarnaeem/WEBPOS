*/
DROP DATABASE IF EXISTS point_of_sales;

CREATE DATABASE IF NOT EXISTS point_of_sales;

USE point_of_sales;

/* *************************************************************** 
***************************CREATING TABLES************************
**************************************************************** */
CREATE TABLE Employee (
	emp_num NUMERIC(11) PRIMARY KEY,
	name VARCHAR(25),
	phone NUMERIC (11),
	address VARCHAR (50),
	password VARCHAR(25),
	email VARCHAR(30),
	);

CREATE TABLE supplier (
	supplier_id NUMERIC(11) PRIMARY KEY,
	supplier_name VARCHAR(40),
	phone_no INT(11),
	address VARCHAR (50),
	product_id NUMERIC(11)
	);

CREATE TABLE locations (
	product_id NUMERIC(11),
	phone_no INT(11),
	expiry_date DATE,
	manufacture_date DATE,
	price INT(10),
	INDEX(product_id),
    CONSTRAINT PK_Product PRIMARY KEY (product_id,product_name),
    CONSTRAINT FK_product_supplier FOREIGN KEY(product_id) REFERENCES supplier(EMP_NUM)
	);
